
import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search as SearchIcon, X, Bookmark, Share2, Filter, Play, Pause, Volume2 } from 'lucide-react';
import { searchBible, getVerseAudio } from '../services/bibleService';
import { Verse } from '../types';
import { useSavedVerses } from '../context/SavedVersesContext';
import { useAppearance } from '../context/AppearanceContext';

export default function Search() {
  const { saveVerse, removeVerse, isSaved } = useSavedVerses();
  const { highlightColor } = useAppearance();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Verse[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [playingVerseId, setPlayingVerseId] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  const handleSearch = async (preQuery?: string) => {
    const activeQuery = preQuery || query;
    if (!activeQuery.trim()) return;
    setLoading(true);
    setSearched(true);
    setPlayingVerseId(null);
    setAudioUrl(null);
    try {
      const data = await searchBible(activeQuery);
      setResults(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayVerse = async (verse: Verse) => {
    if (playingVerseId === verse.id) {
      setPlayingVerseId(null);
      setAudioUrl(null);
      return;
    }

    setPlayingVerseId(verse.id);
    const url = await getVerseAudio(verse.text);
    setAudioUrl(url);
  };

  const handleShare = (verse: Verse) => {
     const text = `"${verse.text}" - ${verse.book} ${verse.chapter}:${verse.verse} (GNT)`;
     if (navigator.share) {
       navigator.share({ title: 'Search Result', text })
         .catch(err => {
           console.error('Error sharing:', err);
           copyToClipboard(text);
         });
     } else {
       copyToClipboard(text);
     }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Verse copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy:', err);
    });
  };

  return (
    <div className="p-6 space-y-6 pb-32">
      <header className="space-y-4 pt-4">
        <h1 className="text-3xl font-serif font-bold text-brand-ink">Search</h1>
        <div className="relative">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Search keywords or topics..."
            className="w-full bg-white border border-brand-blue-main/10 rounded-3xl px-12 py-5 shadow-sm text-brand-ink placeholder:text-gray-300 focus:ring-2 focus:ring-brand-blue-main/20 outline-none transition-all"
          />
          <SearchIcon size={20} className="absolute left-5 top-1/2 -translate-y-1/2 text-brand-blue-main" />
          {query && (
            <button 
              onClick={() => { setQuery(''); setResults([]); setSearched(false); }}
              className="absolute right-5 top-1/2 -translate-y-1/2 p-2 text-gray-300 hover:text-brand-blue-main"
            >
              <X size={18} />
            </button>
          )}
        </div>
        <div className="flex gap-2">
           <button 
             onClick={() => { setQuery('Old Testament'); handleSearch('Old Testament'); }}
             className="px-4 py-1.5 bg-white border border-brand-blue-main/10 rounded-full text-[9px] uppercase font-black tracking-widest text-brand-blue-main/60 flex items-center gap-2 hover:bg-brand-blue-main/5 transition-colors shadow-sm"
           >
             <Filter size={12} /> Old Testament
           </button>
           <button 
             onClick={() => { setQuery('New Testament'); handleSearch('New Testament'); }}
             className="px-4 py-1.5 bg-white border border-brand-blue-main/10 rounded-full text-[9px] uppercase font-black tracking-widest text-brand-blue-main/60 flex items-center gap-2 hover:bg-brand-blue-main/5 transition-colors shadow-sm"
           >
             <Filter size={12} /> New Testament
           </button>
        </div>
      </header>

      <section className="space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-4">
             <div className="w-10 h-10 border-4 border-brand-blue-main/20 border-t-brand-blue-main rounded-full animate-spin" />
             <p className="font-serif italic text-brand-blue-main/40">Seeking the scrolls...</p>
          </div>
        ) : (
          <div className="space-y-6">
            {results.map((v, i) => (
              <motion.div
                key={v.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ 
                  opacity: 1, 
                  y: 0,
                  backgroundColor: playingVerseId === v.id ? highlightColor + '40' : 'rgba(255, 255, 255, 1)'
                }}
                transition={{ delay: i * 0.05 }}
                className={`p-6 rounded-[32px] border border-brand-blue-main/5 shadow-md space-y-4 transition-all duration-500`}
              >
                <div className="flex justify-between items-center">
                   <h3 className="text-[10px] font-black text-brand-blue-main uppercase tracking-widest">{v.book} {v.chapter}:{v.verse}</h3>
                    <div className="flex gap-2 text-gray-400">
                      <button 
                        onClick={() => handlePlayVerse(v)}
                        className={`p-2 transition-colors rounded-full ${playingVerseId === v.id ? 'text-brand-blue-main bg-brand-blue-main/5' : 'hover:text-brand-blue-main hover:bg-brand-blue-main/5'}`}
                      >
                        {playingVerseId === v.id ? <Pause size={18} /> : <Play size={18} />}
                      </button>
                      <button 
                        onClick={() => isSaved(v.id) ? removeVerse(v.id) : saveVerse(v)}
                        className={`p-2 rounded-full transition-colors ${isSaved(v.id) ? 'text-brand-gold bg-brand-gold/5' : 'hover:text-brand-blue-main hover:bg-brand-blue-main/5'}`}
                      >
                        <Bookmark size={18} fill={isSaved(v.id) ? "currentColor" : "none"} />
                      </button>
                      <button 
                        onClick={() => handleShare(v)}
                        className="p-2 hover:text-brand-blue-main hover:bg-brand-blue-main/5 rounded-full transition-colors"
                      >
                        <Share2 size={18} />
                      </button>
                   </div>
                </div>
                <p 
                  onClick={() => handlePlayVerse(v)}
                  className={`font-serif text-lg leading-relaxed italic cursor-pointer transition-colors ${playingVerseId === v.id ? 'text-brand-blue-main font-medium' : 'text-gray-900 hover:text-brand-blue-main/70'}`}
                >
                  "{v.text}"
                </p>
              </motion.div>
            ))}
            {searched && results.length === 0 && !loading && (
              <div className="text-center py-24 space-y-3">
                <p className="font-serif text-brand-blue-main/40 italic text-xl">No matches in the Word.</p>
                <p className="text-[10px] text-gray-400 uppercase font-black tracking-[0.2em]">Try broadening your search</p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Audio Player Container */}
      {audioUrl && playingVerseId && (
        <audio 
          ref={audioRef}
          src={audioUrl} 
          autoPlay 
          onEnded={() => {
            setPlayingVerseId(null);
            setAudioUrl(null);
          }}
          className="hidden"
        />
      )}
    </div>
  );
}
