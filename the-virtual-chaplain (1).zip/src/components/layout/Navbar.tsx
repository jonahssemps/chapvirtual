
import { Home, BookOpen, Scroll, MessageCircle, Settings, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { useAppearance } from '../../context/AppearanceContext';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Navbar({ activeTab, setActiveTab }: NavbarProps) {
  const { t } = useLanguage();
  const { setBibleSource } = useAppearance();
  const tabs = [
    { id: 'home', icon: Home, label: t('home') },
    { id: 'bible', icon: BookOpen, label: t('bible') },
    { id: 'plans', icon: Scroll, label: t('plans') },
    { id: 'search', icon: Search, label: t('search') },
    { id: 'chaplain', icon: MessageCircle, label: t('chaplain') },
    { id: 'settings', icon: Settings, label: t('settings') },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md border-t border-brand-blue-main/5 px-4 py-3 pb-safe z-50 shadow-[0_-8px_30px_rgb(0,0,0,0.05)]">
      <div className="max-w-md mx-auto flex justify-between items-center">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                if (tab.id === 'bible') setBibleSource('nav');
              }}
              className="flex flex-col items-center gap-1 group relative"
              id={`nav-tab-${tab.id}`}
            >
              <div className={`p-2.5 rounded-2xl transition-all duration-300 ${isActive ? 'bg-brand-blue-main text-white scale-110 shadow-lg shadow-brand-blue-main/20' : 'text-gray-400 group-hover:text-brand-blue-main/60'}`}>
                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[8px] font-black uppercase tracking-[0.1em] transition-colors ${isActive ? 'text-brand-blue-main' : 'text-gray-300'}`}>
                {tab.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute -top-3.5 left-1/2 -translate-x-1/2 w-6 h-1 bg-brand-gold rounded-full"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
