
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Share2, Bookmark, Play, Pause, Quote, Church, Sparkles, Heart, Info, BookOpen, Scroll } from 'lucide-react';
import { generateDailyVerse } from '../services/geminiService';
import { getVerseAudio } from '../services/bibleService';
import { useLanguage } from '../context/LanguageContext';
import { useSavedVerses } from '../context/SavedVersesContext';

export default function Home() {
  const { t } = useLanguage();
  const { saveVerse, removeVerse, isSaved } = useSavedVerses();
  const [dailyVerse, setDailyVerse] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const [selectedPrayer, setSelectedPrayer] = useState<any>(null);

  const commonPrayers = [
    { 
      title: "The Lord's Prayer", 
      text: "Our Father in heaven, hallowed be your name, your kingdom come, your will be done, on earth as it is in heaven. Give us today our daily bread. And forgive us our debts, as we also have forgiven our debtors. And lead us not into temptation, but deliver us from the evil one.",
      short: "Our Father in heaven, hallowed be your name, your kingdom come, your will be done, on earth as it is in heaven..."
    },
    { 
      title: "Hail Mary", 
      text: "Hail Mary, full of grace, the Lord is with thee; blessed art thou among women, and blessed is the fruit of thy womb, Jesus. Holy Mary, Mother of God, pray for us sinners, now and at the hour of our death. Amen.",
      short: "Hail Mary, full of grace, the Lord is with thee; blessed art thou among women, and blessed is the fruit of thy womb, Jesus..."
    },
    { 
      title: "Glory Be", 
      text: "Glory be to the Father, and to the Son, and to the Holy Spirit. As it was in the beginning, is now, and ever shall be, world without end. Amen.",
      short: "Glory be to the Father, and to the Son, and to the Holy Spirit. As it was in the beginning, is now, and ever shall be, world without end. Amen."
    }
  ];

  const saintOfTheDay = {
    name: "Saint Pancras",
    date: "May 12",
    story: "Saint Pancras was a Roman citizen who converted to Christianity and was beheaded for his faith at the age of 14, around the year 304. He is known as a symbol of youthful dedication and is often invoked against false witness and perjury.",
    image: "https://images.unsplash.com/photo-1548625361-90c00ef6efb0?q=80&w=400&h=300&fit=crop"
  };

  const ugandaMartyrs = [
    {
      name: "St. Charles Lwanga",
      age: "25",
      birthPlace: "Bulimu, Buganda",
      story: "Leader of the royal pages, he protected the younger pages from King Mwanga's advances. He baptized his companions and was burned to death at Namugongo while praying for his executioners.",
      color: "bg-black",
      image: "https://images.unsplash.com/photo-1548625361-90c00ef6efb0?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Kizito",
      age: "14",
      birthPlace: "Waluleeta, Bulemeezi",
      story: "The youngest martyr. He went to his death laughing and praising God, encouraging his elder companions. He was wrapped in reeds and burned alive at Namugongo.",
      color: "bg-brand-gold",
      image: "https://images.unsplash.com/photo-1509021436665-8f07dbf5bf1d?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Matthias Kalemba",
      age: "50+",
      birthPlace: "Bunya, Busoga",
      story: "Known as 'The Mulumba', he was a judge. He was martyred with extreme cruelty; his limbs were severed and he was left to die in the wilderness, which he endured for three days in prayer.",
      color: "bg-red-600",
      image: "https://images.unsplash.com/photo-1544427928-c49cdfebf194?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Andrew Kaggwa",
      age: "30",
      birthPlace: "Bunyoro",
      story: "The king's bandmaster and a great catechist. He was beheaded after having his arms severed. He remained steadfast in his refusal to renounce Christ.",
      color: "bg-black",
      image: "https://images.unsplash.com/photo-1519810755548-39cd217da494?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Pontiano Ngondwe",
      age: "40",
      birthPlace: "Bulimu, Kyaggwe",
      story: "A soldier in the king's guard. He was speared to death while being marched to the place of execution, refusing to abandon his faith even at the point of a spear.",
      color: "bg-brand-gold",
      image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Joseph Mukasa Balikuddembe",
      age: "26",
      birthPlace: "Mawokota",
      story: "The first Catholic martyr. He was the head of the pages and advisor to the King. He was beheaded and burned for rebuking the king for the murder of Bishop Hannington.",
      color: "bg-red-600",
      image: "https://images.unsplash.com/photo-1515536069122-8ad200d6c5a7?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Noa Mawaggali",
      age: "35",
      birthPlace: "Ssingo",
      story: "A potter and tanner. He was speared and then tied to a tree where dogs were set upon him. He met his death with profound humility and courage.",
      color: "bg-black",
      image: "https://images.unsplash.com/photo-1464692805480-a69dfaafdb0d?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Achilles Kiwanuka",
      age: "17",
      birthPlace: "Ssingo",
      story: "A clerk at the court. He renounced all traditional practices after conversion and was burned alive with his companions at Namugongo.",
      color: "bg-brand-gold",
      image: "https://images.unsplash.com/photo-1520844390616-56f8f117f35a?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Ambrose Kibuuka",
      age: "18",
      birthPlace: "Ssingo",
      story: "A page at the court. He was known for his joyful spirit and was among those burned at the Great Stake of Namugongo.",
      color: "bg-red-600",
      image: "https://images.unsplash.com/photo-1516733725897-1aa73b87c8e8?q=80&w=400&h=600&fit=crop"
    },
    {
      name: "St. Jean-Marie Muzeeyi",
      age: "35",
      birthPlace: "Buddu",
      story: "The last of the martyrs to die. He was a healer known for his deep prayer life. He was beheaded and his body thrown into a swamp.",
      color: "bg-black",
      image: "https://images.unsplash.com/photo-1444491741275-3747c53c99b4?q=80&w=400&h=600&fit=crop"
    }
  ];

  useEffect(() => {
    async function loadVerse() {
      const verse = await generateDailyVerse();
      setDailyVerse(verse);
      setLoading(false);
    }
    loadVerse();
  }, []);

  const handlePlayAudio = async () => {
    if (isPlaying) {
      setIsPlaying(false);
      return;
    }

    if (!audioUrl && dailyVerse) {
      const url = await getVerseAudio(dailyVerse.text);
      setAudioUrl(url);
    }

    setIsPlaying(true);
  };

  const handleShare = () => {
    if (dailyVerse) {
      const text = `"${dailyVerse.text}" - ${dailyVerse.reference}\nShared from THE VIRTUAL CHAPLAIN app.`;
      if (navigator.share) {
        navigator.share({ title: 'Verse of the Day', text });
      } else {
        alert('Sharing not supported on this browser');
      }
    }
  };

  const handleSave = () => {
    if (dailyVerse) {
      const verseObj = {
        id: dailyVerse.reference.replace(/\s+/g, '-').toLowerCase(),
        book: dailyVerse.reference.split(' ')[0],
        chapter: 1, 
        verse: 1, 
        text: dailyVerse.text
      };
      if (isSaved(verseObj.id)) {
        removeVerse(verseObj.id);
      } else {
        saveVerse(verseObj);
      }
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <div className="w-12 h-12 border-4 border-brand-blue-main/20 border-t-brand-blue-main rounded-full animate-spin" />
        <p className="font-serif italic text-brand-blue-main/60">{t('gatheringWisdom')}</p>
      </div>
    );
  }

  return (
    <div className="px-6 py-8 space-y-12 pb-32">
      {/* Header */}
      <header className="flex items-center gap-4">
        <div className="w-16 h-16 bg-brand-blue-main rounded-3xl flex items-center justify-center text-white shadow-lg">
          <Church size={32} />
        </div>
        <div className="space-y-0.5">
          <h1 className="text-3xl font-serif font-bold text-brand-ink leading-tight">{t('virtualChaplain')}</h1>
          <p className="text-[10px] text-brand-blue-main font-bold tracking-[0.2em] uppercase">{t('onlineGuidance')}</p>
        </div>
      </header>

      {/* Verse of the Day Card */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[40px] p-8 shadow-xl border border-brand-blue-main/5 relative overflow-hidden group"
      >
        <div className="absolute top-4 right-8 opacity-5">
           <Quote size={80} className="text-brand-blue-main" />
        </div>

        <div className="space-y-6 relative z-10">
          <div className="flex items-center gap-2">
            <Sparkles size={14} className="text-brand-gold" />
            <span className="text-[10px] uppercase tracking-widest font-black text-brand-blue-main">
              {t('verseOfToday')}
            </span>
          </div>
          
          <div className="space-y-4">
            <p className="text-2xl font-serif leading-relaxed italic text-brand-ink">
              "{dailyVerse?.text}"
            </p>
            <p className="text-brand-blue-main font-bold tracking-wide italic">
              — {dailyVerse?.reference}
            </p>
          </div>

          <div className="pt-6 border-t border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button 
                onClick={handlePlayAudio}
                className="w-12 h-12 rounded-full bg-brand-blue-main text-white flex items-center justify-center hover:bg-brand-blue-main/90 transition-all active:scale-95 shadow-md"
              >
                {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-1" />}
              </button>
              <div className="flex flex-col">
                <span className="text-[10px] font-bold uppercase tracking-tighter text-gray-400">{t('audioReading')}</span>
                <span className="text-xs font-medium text-gray-600">{t('gntTranslation')}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={handleShare} className="p-3 text-gray-400 hover:text-brand-blue-main hover:bg-brand-blue-main/5 rounded-full transition-colors">
                <Share2 size={24} />
              </button>
              <button 
                onClick={handleSave}
                className={`p-3 rounded-full transition-all ${isSaved(dailyVerse?.reference.replace(/\s+/g, '-').toLowerCase()) ? 'text-brand-gold bg-brand-gold/10' : 'text-gray-400 hover:text-brand-blue-main hover:bg-brand-blue-main/5'}`}
              >
                <Bookmark size={24} fill={isSaved(dailyVerse?.reference.replace(/\s+/g, '-').toLowerCase()) ? "currentColor" : "none"} />
              </button>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Common Prayers Section */}
      <section className="space-y-4">
        <h2 className="text-[10px] uppercase tracking-[0.3em] font-black text-brand-blue-main/40 px-2 flex items-center gap-2">
          <Heart size={14} /> {t('commonPrayers')}
        </h2>
        <div className="flex gap-4 overflow-x-auto pb-4 custom-scrollbar snap-x">
          {commonPrayers.map((prayer, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="min-w-[280px] bg-white p-6 rounded-[32px] border border-brand-blue-main/5 shadow-md snap-center space-y-3"
            >
              <h3 className="font-serif font-bold text-brand-blue-main">{prayer.title}</h3>
              <p className="text-sm text-gray-600 line-clamp-4 leading-relaxed italic">"{prayer.short}"</p>
              <button 
                onClick={() => setSelectedPrayer(prayer)}
                className="text-[10px] uppercase font-black tracking-widest text-brand-blue-main/60 flex items-center gap-1 hover:text-brand-blue-main transition-colors"
              >
                {t('readFull')} <BookOpen size={10} />
              </button>
            </motion.div>
          ))}
        </div>
      </section>
      
      {/* Saint of the Day */}
      <section className="space-y-4">
        <h2 className="text-[10px] uppercase tracking-[0.3em] font-black text-brand-blue-main/40 px-2 flex items-center gap-2">
          <Sparkles size={14} /> {t('saintOfTheDay')}
        </h2>
        <div className="bg-white rounded-[40px] overflow-hidden border border-brand-blue-main/5 shadow-md flex flex-col md:flex-row">
          <div className="md:w-1/3 h-48 md:h-auto overflow-hidden">
             <img src={saintOfTheDay.image} alt={saintOfTheDay.name} className="w-full h-full object-cover" />
          </div>
          <div className="p-8 md:w-2/3 space-y-4">
            <div className="flex justify-between items-center">
               <h3 className="text-xl font-serif font-bold text-brand-ink">{saintOfTheDay.name}</h3>
               <span className="text-[10px] font-black text-brand-blue-main uppercase tracking-widest bg-brand-blue-main/5 px-3 py-1 rounded-full">{saintOfTheDay.date}</span>
            </div>
            <p className="text-sm text-gray-600 leading-relaxed italic">"{saintOfTheDay.story}"</p>
          </div>
        </div>
      </section>

      {/* Uganda Martyrs */}
      <section className="space-y-4">
        <div className="flex justify-between items-center px-2">
          <h2 className="text-[10px] uppercase tracking-[0.3em] font-black text-brand-blue-main/40 flex items-center gap-2">
            <Scroll size={14} /> {t('ugandaMartyrs')}
          </h2>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-6 custom-scrollbar snap-x px-2">
          {ugandaMartyrs.map((martyr, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className={`min-w-[320px] ${martyr.color} text-white p-8 rounded-[48px] shadow-xl snap-center flex flex-col justify-between h-[500px] relative overflow-hidden group`}
            >
              <div className="absolute inset-0 z-0">
                 <img src={martyr.image} alt={martyr.name} className="w-full h-full object-cover opacity-20 transition-transform duration-1000 group-hover:scale-110" />
                 <div className={`absolute inset-0 bg-gradient-to-t from-${martyr.color === 'bg-black' ? 'black' : martyr.color.replace('bg-', '')} via-transparent to-transparent opacity-80`} />
              </div>
              
              <div className="space-y-4 relative z-10">
                <h3 className="text-2xl font-serif font-bold leading-tight">{martyr.name}</h3>
                <div className="flex flex-wrap gap-4 pt-2">
                  <div className="flex flex-col">
                    <span className="text-[8px] uppercase tracking-widest font-black opacity-60">{t('ageOfDeath')}</span>
                    <span className="text-sm font-bold">{martyr.age}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[8px] uppercase tracking-widest font-black opacity-60">{t('placeOfBirth')}</span>
                    <span className="text-sm font-bold">{martyr.birthPlace}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3 relative z-10">
                 <div className="flex items-center gap-2">
                   <div className="h-[1px] w-8 bg-white/40" />
                   <span className="text-[8px] uppercase tracking-widest font-black opacity-60">{t('story')}</span>
                 </div>
                 <p className="text-sm leading-relaxed font-medium line-clamp-8 opacity-90 italic">
                   "{martyr.story}"
                 </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Prayer Modal */}
      <AnimatePresence>
        {selectedPrayer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-6"
            onClick={() => setSelectedPrayer(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[40px] p-8 max-w-md w-full shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={() => setSelectedPrayer(null)}
                className="absolute top-6 right-6 text-gray-400 hover:text-gray-600"
              >
                <Sparkles size={20} />
              </button>
              <h2 className="text-2xl font-serif font-bold text-brand-ink mb-4">{selectedPrayer.title}</h2>
              <p className="text-lg leading-relaxed font-serif italic text-gray-700">
                "{selectedPrayer.text}"
              </p>
              <button 
                onClick={() => setSelectedPrayer(null)}
                className="w-full mt-8 bg-brand-blue-main text-white py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg hover:bg-brand-blue-main/90 transition-all"
              >
                {t('closePrayer')}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* About Section */}
      <section className="space-y-4">
        <h2 className="text-[10px] uppercase tracking-[0.3em] font-black text-brand-blue-main/40 px-2 flex items-center gap-2">
          <Info size={14} /> {t('aboutMinistry')}
        </h2>
        <div className="bg-white p-8 rounded-[40px] border border-brand-blue-main/5 shadow-md space-y-6">
          <div className="flex items-center gap-4">
             <div className="w-12 h-12 bg-brand-gold rounded-2xl flex items-center justify-center text-brand-blue-main shadow-sm font-black italic">SJ</div>
             <div>
                <h3 className="font-serif font-bold text-brand-ink">Ssempuuma Jonathan</h3>
                <p className="text-[10px] text-brand-blue-main uppercase font-black tracking-widest">{t('creatorVisionary')}</p>
             </div>
          </div>
          <div className="space-y-4">
            <p className="text-sm text-gray-700 leading-relaxed font-medium">
              This digital sanctuary was crafted by <span className="text-brand-blue-main font-bold">Ssempuuma Jonathan</span>, who found his spiritual anchor at <span className="text-brand-blue-main font-bold">St. Joseph's S.S.S Naggalama</span>. Inspired by the profound spiritual teachings and discipline of his alma mater, he seeks to bring constant companionship to every soul through modern technology.
            </p>
            
            <div className="pt-4 border-t border-gray-50 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles size={14} className="text-brand-gold" />
                <span className="text-[10px] uppercase tracking-widest font-black text-brand-blue-main">{t('spiritualInspiration')}</span>
              </div>
              <h4 className="font-serif font-bold text-brand-ink">Blessed Carlo Acutis</h4>
              <p className="text-xs text-gray-600 leading-relaxed italic">
                Ssempuuma was deeply encouraged by the life of <span className="font-bold">Blessed Carlo Acutis</span>, the "Cyber-apostle of the Eucharist." Carlo was a typical teenager who used his coding skills to document Eucharistic miracles online. He once said, "To always be close to Jesus, that is my life plan." Carlo's legacy proves that technology can be a powerful vessel for faith, inspiring this Virtual Chaplain to exist.
              </p>
              <div className="bg-brand-blue-main/5 p-4 rounded-2xl">
                <p className="text-[10px] text-brand-blue-main font-medium italic">
                  "The more we receive the Eucharist, the more we will become like Jesus, so that on earth we will have a foretaste of heaven." — Carlo Acutis
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="pt-8 pb-12 text-center border-t border-brand-blue-main/5">
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-blue-main/30">
          @2026 THE VIRTUAL CHAPLAIN @Ssemps Inc.
        </p>
      </footer>

      {audioUrl && isPlaying && (
        <audio 
          src={audioUrl} 
          autoPlay 
          onEnded={() => setIsPlaying(false)}
          className="hidden"
        />
      )}
    </div>
  );
}
