
import { motion } from 'motion/react';
import { Scroll, ChevronRight, Clock, Map } from 'lucide-react';
import { ReadingPlan } from '../types';
import { useReading } from '../context/ReadingContext';
import { useAppearance } from '../context/AppearanceContext';

interface PlansProps {
  setActiveTab: (tab: string) => void;
}

export default function Plans({ setActiveTab }: PlansProps) {
  const { activePlans, availablePlans, startPlan } = useReading();
  const { setBibleSource } = useAppearance();

  return (
    <div className="p-6 space-y-8 pb-32">
      <header className="space-y-1 pt-4">
        <h1 className="text-3xl font-serif font-bold text-brand-ink">Reading Plans</h1>
        <p className="text-sm text-brand-blue-main/60">Your journey through the Holy Word</p>
      </header>

      {/* Active Plans */}
      <section className="space-y-4">
        <h2 className="text-[10px] uppercase tracking-[0.2em] font-black text-brand-blue-main/40 flex items-center gap-2 px-1">
          <Map size={14} className="text-brand-blue-main" /> My Journey
        </h2>
        <div className="grid gap-6">
          {activePlans.length === 0 ? (
            <div className="bg-brand-blue-main/5 p-8 rounded-[32px] text-center border border-dashed border-brand-blue-main/20">
              <p className="text-brand-blue-main/40 font-serif italic">Your spiritual journey is waiting to begin...</p>
            </div>
          ) : activePlans.map(plan => (
            <motion.div 
              key={plan.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -4 }}
              className="bg-white p-6 rounded-[32px] shadow-md border border-brand-blue-main/5 space-y-5 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-brand-blue-main/5 rounded-full -mr-12 -mt-12" />
              
              <div className="flex justify-between items-start relative">
                <div className="space-y-1">
                  <h3 className="font-serif font-bold text-xl text-brand-ink">{plan.title}</h3>
                  <p className="text-xs text-gray-500 line-clamp-1 italic">{plan.description}</p>
                </div>
                <div className="bg-brand-blue-main text-white px-3 py-1 rounded-full shadow-sm">
                  <span className="text-[10px] font-black">{plan.progress}%</span>
                </div>
              </div>
              
              <div className="h-2 w-full bg-gray-50 rounded-full overflow-hidden">
                <motion.div 
                   initial={{ width: 0 }}
                   animate={{ width: `${plan.progress}%` }}
                   className="h-full bg-brand-blue-main rounded-full"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-4 text-[9px] font-black uppercase tracking-widest text-gray-400">
                  <span className="flex items-center gap-1.5"><Clock size={12} className="text-brand-blue-main/60" /> {plan.pace} pace</span>
                  <span className="flex items-center gap-1.5"><Scroll size={12} className="text-brand-blue-main/60" /> {plan.totalDays} days</span>
                </div>
                <button 
                  onClick={() => {
                    setBibleSource('plan');
                    setActiveTab('bible');
                  }}
                  className="text-xs font-black uppercase tracking-widest text-brand-blue-main flex items-center gap-1 group"
                >
                  Continue <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Explorations */}
      <section className="space-y-4">
        <h2 className="text-[10px] uppercase tracking-[0.2em] font-black text-brand-blue-main/40 flex items-center gap-2 px-1">
          <Scroll size={14} className="text-brand-blue-main" /> Explore Plans
        </h2>
        <div className="grid gap-3">
          {availablePlans.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-xs text-brand-blue-main/40 font-bold uppercase tracking-widest">All current plans active</p>
            </div>
          ) : availablePlans.map(plan => (
            <motion.div 
              key={plan.id}
              layout
              onClick={() => startPlan(plan)}
              className="bg-white p-5 rounded-3xl border border-brand-blue-main/5 flex items-center justify-between group cursor-pointer hover:bg-brand-blue-main/5 hover:border-brand-blue-main/20 transition-all shadow-sm"
            >
              <div className="space-y-1.5">
                <h4 className="font-bold text-brand-ink group-hover:text-brand-blue-main transition-colors">{plan.title}</h4>
                <div className="flex items-center gap-3 text-[9px] text-gray-400 font-black uppercase tracking-widest">
                   <span className="bg-brand-blue-main/5 px-2 py-0.5 rounded text-brand-blue-main">{plan.type}</span>
                   <span>{plan.totalDays} days</span>
                </div>
              </div>
              <button 
                className="w-10 h-10 rounded-2xl bg-brand-blue-main flex items-center justify-center text-white shadow-lg shadow-brand-blue-main/10 group-hover:scale-110 transition-transform"
              >
                <ChevronRight size={18} />
              </button>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
