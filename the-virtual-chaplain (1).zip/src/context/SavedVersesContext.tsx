
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Verse, Bookmark } from '../types';

interface SavedVersesContextType {
  savedVerses: Bookmark[];
  saveVerse: (verse: Verse) => void;
  removeVerse: (verseId: string) => void;
  isSaved: (verseId: string) => boolean;
}

const SavedVersesContext = createContext<SavedVersesContextType | undefined>(undefined);

export function SavedVersesProvider({ children }: { children: ReactNode }) {
  const [savedVerses, setSavedVerses] = useState<Bookmark[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('saved_verses');
    if (stored) {
      try {
        setSavedVerses(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse saved verses', e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('saved_verses', JSON.stringify(savedVerses));
  }, [savedVerses]);

  const saveVerse = (verse: Verse) => {
    if (isSaved(verse.id)) return;

    const newBookmark: Bookmark = {
      id: `${Date.now()}-${verse.id}`,
      verseId: verse.id,
      book: verse.book,
      chapter: verse.chapter,
      verse: verse.verse,
      text: verse.text,
      createdAt: Date.now(),
    };

    setSavedVerses(prev => [newBookmark, ...prev]);
  };

  const removeVerse = (verseId: string) => {
    setSavedVerses(prev => prev.filter(v => v.verseId !== verseId));
  };

  const isSaved = (verseId: string) => {
    return savedVerses.some(v => v.verseId === verseId);
  };

  return (
    <SavedVersesContext.Provider value={{ savedVerses, saveVerse, removeVerse, isSaved }}>
      {children}
    </SavedVersesContext.Provider>
  );
}

export function useSavedVerses() {
  const context = useContext(SavedVersesContext);
  if (context === undefined) {
    throw new Error('useSavedVerses must be used within a SavedVersesProvider');
  }
  return context;
}
