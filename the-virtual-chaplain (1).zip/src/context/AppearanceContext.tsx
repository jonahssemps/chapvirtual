
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AppearanceContextType {
  highlightColor: string;
  setHighlightColor: (color: string) => void;
  bibleSource: 'nav' | 'plan';
  setBibleSource: (source: 'nav' | 'plan') => void;
  targetVerse: { bookName: string; chapter: number; verse?: number } | null;
  navigateToVerse: (bookName: string, chapter: number, verse?: number) => void;
  clearTargetVerse: () => void;
}

const AppearanceContext = createContext<AppearanceContextType | undefined>(undefined);

export function AppearanceProvider({ children }: { children: ReactNode }) {
  const [highlightColor, setHighlightColor] = useState('#fde047');
  const [bibleSource, setBibleSource] = useState<'nav' | 'plan'>('nav');
  const [targetVerse, setTargetVerse] = useState<{ bookName: string; chapter: number; verse?: number } | null>(null);

  useEffect(() => {
    const storedColor = localStorage.getItem('highlight_color');
    if (storedColor) {
      setHighlightColor(storedColor);
    }
  }, []);

  const handleSetHighlightColor = (color: string) => {
    setHighlightColor(color);
    localStorage.setItem('highlight_color', color);
  };

  const navigateToVerse = (bookName: string, chapter: number, verse?: number) => {
    setTargetVerse({ bookName, chapter, verse });
    setBibleSource('nav');
  };

  const clearTargetVerse = () => setTargetVerse(null);

  return (
    <AppearanceContext.Provider value={{ 
      highlightColor, 
      setHighlightColor: handleSetHighlightColor,
      bibleSource,
      setBibleSource,
      targetVerse,
      navigateToVerse,
      clearTargetVerse
    }}>
      {children}
    </AppearanceContext.Provider>
  );
}

export function useAppearance() {
  const context = useContext(AppearanceContext);
  if (context === undefined) {
    throw new Error('useAppearance must be used within an AppearanceProvider');
  }
  return context;
}
