
import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'English' | 'French';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  English: {
    home: 'Home',
    bible: 'Bible',
    plans: 'Plans',
    search: 'Search',
    chaplain: 'Chaplain',
    settings: 'Settings',
    appearance: 'Appearance',
    fontSize: 'Font Size',
    bibleVersion: 'Bible Version',
    remindersSync: 'Reminders & Sync',
    dailyReminders: 'Daily Reminders',
    cloudBackup: 'Cloud Backup',
    language: 'Language',
    signOut: 'Sign Out',
    editProfile: 'Edit Profile',
    displayName: 'Display Name',
    chooseAvatar: 'Choose Avatar',
    saveChanges: 'Save Changes',
    spiritualDiscipline: 'Spiritual Discipline',
    dailyPrayerReminder: 'Daily Prayer Reminder',
    receiveVerse: 'Receive a verse at your chosen hour',
    setTime: 'Set Time',
    devoutSoul: 'Devout Soul',
    active: 'Active',
    disabled: 'Disabled',
    virtualChaplain: 'The Virtual Chaplain',
    onlineGuidance: 'Online Spiritual Guidance',
    verseOfToday: 'Verse of the Day',
    audioReading: 'Audio Reading',
    gntTranslation: 'GNT Translation',
    commonPrayers: 'Common Prayers',
    readFull: 'Read Full',
    closePrayer: 'Close Prayer',
    aboutMinistry: 'About the Ministry',
    creatorVisionary: 'Creator & Visionary',
    spiritualInspiration: 'Spiritual Inspiration',
    gatheringWisdom: 'Gathering wisdom for today...',
    savedVerses: 'Saved Verses',
    noSavedVerses: 'No verses saved yet. Find inspiration in the Word.',
    highlightColor: 'Highlight Color',
    saintOfTheDay: 'Saint of the Day',
    ugandaMartyrs: 'The Uganda Martyrs',
    ageOfDeath: 'Age of Death',
    placeOfBirth: 'Place of Birth',
    story: 'Their Story'
  },
  French: {
    home: 'Accueil',
    bible: 'Bible',
    plans: 'Plans',
    search: 'Recherche',
    chaplain: 'Aumônier',
    settings: 'Paramètres',
    appearance: 'Apparence',
    fontSize: 'Taille de police',
    bibleVersion: 'Version de la Bible',
    remindersSync: 'Rappels et Synchro',
    dailyReminders: 'Rappels Quotidiens',
    cloudBackup: 'Sauvegarde Cloud',
    language: 'Langue',
    signOut: 'Se Déconnecter',
    editProfile: 'Modifier le Profil',
    displayName: 'Nom d\'affichage',
    chooseAvatar: 'Choisir un Avatar',
    saveChanges: 'Enregistrer les modifications',
    spiritualDiscipline: 'Discipline Spirituelle',
    dailyPrayerReminder: 'Rappel de prière quotidien',
    receiveVerse: 'Recevez un verset à l\'heure choisie',
    setTime: 'Régler l\'heure',
    devoutSoul: 'Âme Dévolue',
    active: 'Actif',
    disabled: 'Désactivé',
    virtualChaplain: 'L\'Aumônier Virtuel',
    onlineGuidance: 'Guidance Spirituelle en Ligne',
    verseOfToday: 'Verset du Jour',
    audioReading: 'Lecture Audio',
    gntTranslation: 'Traduction GNT',
    commonPrayers: 'Prières Communes',
    readFull: 'Lire Tout',
    closePrayer: 'Fermer la Prière',
    aboutMinistry: 'À propos du Ministère',
    creatorVisionary: 'Créateur et Visionnaire',
    spiritualInspiration: 'Inspiration Spirituelle',
    gatheringWisdom: 'Recueil de sagesse pour aujourd\'hui...',
    savedVerses: 'Versets Enregistrés',
    noSavedVerses: 'Aucun verset enregistré pour le moment. Trouvez l\'inspiration dans la Parole.',
    highlightColor: 'Couleur de Surlignement',
    saintOfTheDay: 'Saint du Jour',
    ugandaMartyrs: 'Les Martyrs de l\'Ouganda',
    ageOfDeath: 'Âge du Décès',
    placeOfBirth: 'Lieu de Naissance',
    story: 'Leur Histoire'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('English');

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
