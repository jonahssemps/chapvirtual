
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ReadingPlan } from '../types';

interface ReadingContextType {
  activePlans: ReadingPlan[];
  availablePlans: ReadingPlan[];
  startPlan: (plan: ReadingPlan) => void;
  updateProgress: (planId: string, increment: number) => void;
  recordReading: (bookName: string, chapter: number) => void;
}

const INITIAL_ACTIVE_PLANS: ReadingPlan[] = [
  { 
    id: '1', 
    title: 'New Testament in 90 Days', 
    description: 'A deep dive into the Gospels, Epistles, and Revelation.', 
    type: 'book', 
    totalDays: 90, 
    progress: 0, 
    pace: 'standard' 
  },
  { 
    id: '2', 
    title: 'Peace in Trials', 
    description: 'Verses focused on finding comfort during difficult times.', 
    type: 'topic', 
    totalDays: 7, 
    progress: 0, 
    pace: 'slow' 
  }
];

const INITIAL_AVAILABLE_PLANS: ReadingPlan[] = [
  { id: '3', title: 'Chronological Bible', description: 'Read the Bible in the order events occurred.', type: 'chronological', totalDays: 365, progress: 0, pace: 'standard' },
  { id: '4', title: 'Proverbs for Wisdom', description: 'One chapter a day for a month.', type: 'book', totalDays: 31, progress: 0, pace: 'fast' },
  { id: '5', title: 'Managing Anxiety', description: 'Spiritual weapons against fear.', type: 'topic', totalDays: 14, progress: 0, pace: 'standard' }
];

const ReadingContext = createContext<ReadingContextType | undefined>(undefined);

export function ReadingProvider({ children }: { children: ReactNode }) {
  const [activePlans, setActivePlans] = useState<ReadingPlan[]>([]);
  const [availablePlans, setAvailablePlans] = useState<ReadingPlan[]>([]);

  useEffect(() => {
    const savedActive = localStorage.getItem('active_plans');
    const savedAvailable = localStorage.getItem('available_plans');

    if (savedActive) {
      setActivePlans(JSON.parse(savedActive));
    } else {
      setActivePlans(INITIAL_ACTIVE_PLANS);
    }

    if (savedAvailable) {
      setAvailablePlans(JSON.parse(savedAvailable));
    } else {
      setAvailablePlans(INITIAL_AVAILABLE_PLANS);
    }
  }, []);

  useEffect(() => {
    if (activePlans.length > 0) {
      localStorage.setItem('active_plans', JSON.stringify(activePlans));
    }
    if (availablePlans.length > 0) {
      localStorage.setItem('available_plans', JSON.stringify(availablePlans));
    }
  }, [activePlans, availablePlans]);

  const startPlan = (plan: ReadingPlan) => {
    setActivePlans(prev => [...prev, { ...plan, progress: 0 }]);
    setAvailablePlans(prev => prev.filter(p => p.id !== plan.id));
  };

  const updateProgress = (planId: string, increment: number) => {
    setActivePlans(prev => prev.map(plan => {
      if (plan.id === planId) {
        const newProgress = Math.min(100, plan.progress + increment);
        return { ...plan, progress: newProgress };
      }
      return plan;
    }));
  };

  // When a user reads, all active plans get a small boost
  // In a real app, this would be mapped to specific plan tasks
  const recordReading = (bookName: string, chapter: number) => {
    setActivePlans(prev => prev.map(plan => {
      // Increase progress by a percentage relative to total days
      // e.g. if 7 days, 1 chapter might be ~14%
      const increment = Math.ceil(100 / plan.totalDays / 2); // Assume 2 chapters per "Day" for simplicity
      const newProgress = Math.min(100, plan.progress + increment);
      return { ...plan, progress: newProgress };
    }));
  };

  return (
    <ReadingContext.Provider value={{ activePlans, availablePlans, startPlan, updateProgress, recordReading }}>
      {children}
    </ReadingContext.Provider>
  );
}

export function useReading() {
  const context = useContext(ReadingContext);
  if (context === undefined) {
    throw new Error('useReading must be used within a ReadingProvider');
  }
  return context;
}
