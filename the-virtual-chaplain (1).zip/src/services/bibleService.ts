
import { GoogleGenAI, Modality } from "@google/genai";
import { Verse, BibleBook } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const BIBLE_BOOKS: BibleBook[] = [
  { id: 'gen', name: 'Genesis', chapters: 50 },
  { id: 'exo', name: 'Exodus', chapters: 40 },
  { id: 'lev', name: 'Leviticus', chapters: 27 },
  { id: 'num', name: 'Numbers', chapters: 36 },
  { id: 'deu', name: 'Deuteronomy', chapters: 34 },
  { id: 'jos', name: 'Joshua', chapters: 24 },
  { id: 'jdg', name: 'Judges', chapters: 21 },
  { id: 'rut', name: 'Ruth', chapters: 4 },
  { id: '1sa', name: '1 Samuel', chapters: 31 },
  { id: '2sa', name: '2 Samuel', chapters: 24 },
  { id: '1ki', name: '1 Kings', chapters: 22 },
  { id: '2ki', name: '2 Kings', chapters: 25 },
  { id: '1ch', name: '1 Chronicles', chapters: 29 },
  { id: '2ch', name: '2 Chronicles', chapters: 36 },
  { id: 'ezr', name: 'Ezra', chapters: 10 },
  { id: 'neh', name: 'Nehemiah', chapters: 13 },
  { id: 'est', name: 'Esther', chapters: 10 },
  { id: 'job', name: 'Job', chapters: 42 },
  { id: 'psa', name: 'Psalms', chapters: 150 },
  { id: 'pro', name: 'Proverbs', chapters: 31 },
  { id: 'ecc', name: 'Ecclesiastes', chapters: 12 },
  { id: 'sol', name: 'Song of Solomon', chapters: 8 },
  { id: 'isa', name: 'Isaiah', chapters: 66 },
  { id: 'jer', name: 'Jeremiah', chapters: 52 },
  { id: 'lam', name: 'Lamentations', chapters: 5 },
  { id: 'eze', name: 'Ezekiel', chapters: 48 },
  { id: 'dan', name: 'Daniel', chapters: 12 },
  { id: 'hos', name: 'Hosea', chapters: 14 },
  { id: 'joe', name: 'Joel', chapters: 3 },
  { id: 'amo', name: 'Amos', chapters: 9 },
  { id: 'oba', name: 'Obadiah', chapters: 1 },
  { id: 'jon', name: 'Jonah', chapters: 4 },
  { id: 'mic', name: 'Micah', chapters: 7 },
  { id: 'nah', name: 'Nahum', chapters: 3 },
  { id: 'hab', name: 'Habakkuk', chapters: 3 },
  { id: 'zep', name: 'Zephaniah', chapters: 3 },
  { id: 'hag', name: 'Haggai', chapters: 2 },
  { id: 'zec', name: 'Zechariah', chapters: 14 },
  { id: 'mal', name: 'Malachi', chapters: 4 },
  { id: 'mat', name: 'Matthew', chapters: 28 },
  { id: 'mar', name: 'Mark', chapters: 16 },
  { id: 'luk', name: 'Luke', chapters: 24 },
  { id: 'joh', name: 'John', chapters: 21 },
  { id: 'act', name: 'Acts', chapters: 28 },
  { id: 'rom', name: 'Romans', chapters: 16 },
  { id: '1co', name: '1 Corinthians', chapters: 16 },
  { id: '2co', name: '2 Corinthians', chapters: 13 },
  { id: 'gal', name: 'Galatians', chapters: 6 },
  { id: 'eph', name: 'Ephesians', chapters: 6 },
  { id: 'phi', name: 'Philippians', chapters: 4 },
  { id: 'col', name: 'Colossians', chapters: 4 },
  { id: '1th', name: '1 Thessalonians', chapters: 5 },
  { id: '2th', name: '2 Thessalonians', chapters: 3 },
  { id: '1ti', name: '1 Timothy', chapters: 6 },
  { id: '2ti', name: '2 Timothy', chapters: 4 },
  { id: 'tit', name: 'Titus', chapters: 3 },
  { id: 'phm', name: 'Philemon', chapters: 1 },
  { id: 'heb', name: 'Hebrews', chapters: 13 },
  { id: 'jam', name: 'James', chapters: 5 },
  { id: '1pe', name: '1 Peter', chapters: 5 },
  { id: '2pe', name: '2 Peter', chapters: 3 },
  { id: '1jo', name: '1 John', chapters: 5 },
  { id: '2jo', name: '2 John', chapters: 1 },
  { id: '3jo', name: '3 John', chapters: 1 },
  { id: 'jud', name: 'Jude', chapters: 1 },
  { id: 'rev', name: 'Revelation', chapters: 22 }
];

export const getChapter = async (book: string, chapter: number): Promise<Verse[]> => {
  const cacheKey = `bible-cache-${book}-${chapter}`;
  const cached = localStorage.getItem(cacheKey);
  if (cached) return JSON.parse(cached);

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Fetch all verses for ${book} chapter ${chapter} in the Good News Bible (GNT). Return as a JSON array of objects with fields: id (string e.g. "gen-1-1"), book (string), chapter (number), verse (number), text (string).`,
    config: {
      responseMimeType: "application/json",
    }
  });

  const verses = JSON.parse(response.text || '[]');
  localStorage.setItem(cacheKey, JSON.stringify(verses));
  return verses;
};

export const searchBible = async (query: string): Promise<Verse[]> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `You are a Bible search engine. Search the Good News Bible (GNT) for verses matching or relevant to: "${query}". 
    Return the top 10 most relevant results.
    Return ONLY a JSON array of objects with fields: id (string e.g. "book-chapter-verse"), book (string), chapter (number), verse (number), text (string).
    Ensure the text is the exact Good News Bible translation.`,
    config: {
      responseMimeType: "application/json",
    }
  });
  return JSON.parse(response.text || '[]');
};

export const getVerseAudio = async (text: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-tts-preview",
    contents: [{ parts: [{ text: `Read this bible verse clearly and reverently: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (base64Audio) {
    return `data:audio/wav;base64,${base64Audio}`;
  }
  return null;
};
