
export interface Verse {
  id: string;
  book: string;
  chapter: number;
  verse: number;
  text: string;
}

export interface BibleBook {
  id: string;
  name: string;
  chapters: number;
}

export interface ReadingPlan {
  id: string;
  title: string;
  description: string;
  type: 'chronological' | 'topic' | 'book';
  totalDays: number;
  progress: number; // 0 to 100
  lastReadDate?: string;
  pace: 'slow' | 'standard' | 'fast';
}

export interface Bookmark {
  id: string;
  verseId: string;
  book: string;
  chapter: number;
  verse: number;
  text: string;
  createdAt: number;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  bookmarks: Bookmark[];
  activePlans: ReadingPlan[];
  settings: {
    darkMode: boolean;
    fontSize: 'sm' | 'md' | 'lg' | 'xl';
    fontStyle: 'serif' | 'sans';
    notificationsEnabled: boolean;
    reminderTime: string; // "08:00"
    language: string;
  };
}
